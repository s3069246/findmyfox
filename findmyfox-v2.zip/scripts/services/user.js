/*
 * TO DO
 * Incoporate user accounts into the appliation
 */

'use strict';

angular.module('findDeviceApp').provider('user', function() {
    
    
    
});